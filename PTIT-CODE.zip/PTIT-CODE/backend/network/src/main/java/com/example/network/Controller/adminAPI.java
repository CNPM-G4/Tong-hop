package com.example.network.Controller;

import com.example.network.DTO.UserDTO;
import com.example.network.DTO.adminDTO;
import com.example.network.DTO.detailDTO;
import com.example.network.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
public class adminAPI {
    @Autowired
    private UserService userService;

    @CrossOrigin(origins = "http://127.0.0.1:5500")
    @GetMapping("/api/admin/writedata")
    public List<UserDTO> allUser()
    {
        userService.writeUsedData();
        return userService.findAll();
    }

    @CrossOrigin(origins = "http://127.0.0.1:5500")
    @GetMapping("/admin/home")
    public List<adminDTO> userInformation()
    {
        return userService.adminFindAll();
    }
    @CrossOrigin(origins = "http://127.0.0.1:5500")
    @GetMapping("/admin/detail")
    public detailDTO userDetailInfor(@RequestParam(name = "ID") int ID)
    {
        return userService.adminFindDetailInfor(ID);
    }
}
