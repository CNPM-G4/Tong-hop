package com.example.network.Controller;

import com.example.network.DTO.*;
import com.example.network.DTO.Response.totalResponseDTO;
import com.example.network.Entity.User;
import com.example.network.Entity.logged;
import com.example.network.Entity.used;
import com.example.network.Service.UserService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
public class userAPI {

    @Autowired
    private UserService userService;

    @Autowired
    private EntityManager entityManager;

    @Transactional
    @CrossOrigin(origins = "http://127.0.0.1:5500")
    @PostMapping("/login")
    public UserDTO logIn(@RequestBody RequestDTO request)
    {
        if (userService.findAccountByPhone(request.getPhone()) != null)
        {
            User temp = userService.findAccountByPhone(request.getPhone());
            UserDTO result = userService.findByPhoneNumber(request.getPhone());
            if (temp.getPassword().equals(request.getPassword()))
            {
                result.setMessage("Logged in!");
                result.setStatus(true);
                Date date = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String dateOnly = dateFormat.format(date);
                String sql = "INSERT INTO logged (login, userID) VALUES (:login, :userID)";
                Query query = entityManager.createNativeQuery(sql);
                query.setParameter("login", dateOnly);
                query.setParameter("userID", temp.getUserID());
                query.executeUpdate();
                String sql1 = "UPDATE user SET status = true WHERE userID = " + temp.getUserID();
                Query qr1 = entityManager.createNativeQuery(sql1);
                qr1.executeUpdate();
            }else{
                result.setMessage("Wrong password! Please try again!");
                result.setStatus(false);
            }
            return result;
        }else
        {
            UserDTO result = new UserDTO();
            result.setMessage("This account doesn't exist!");
            result.setStatus(false);
            return result;
        }
    }

//    {
//        "name": "nguyenphuonglinh",
//            "password": "pass123",
//            "phone": "0969419682"
//    }
    @CrossOrigin(origins = "http://127.0.0.1:5500")
    @PostMapping("/register")
    public boolean register(@RequestBody RequestDTO newUser)
    {
        return userService.register(newUser.getPhone(), newUser.getName(), newUser.getPassword());
        
    }
    

    @GetMapping("home")
    public homeDTO home(@RequestParam (name = "ID") int ID)
    {
        return userService.findByID(ID);
    }

    @GetMapping("/api/history")
    public historyDTO history(@RequestParam (name = "ID") int ID){
        return userService.findHistoryByID(ID);
    }

    @GetMapping("/total")
    public totalDTO total(@RequestParam(name = "ID") int ID)
    {
        return userService.findTotalByID(ID);
    }

//        {
//        "ID": "1",
//            "total": "2.5",
//            "time": "2.5"
//    }
    @Transactional
    @PostMapping("/logout")
    public boolean logOut(@RequestBody requestUsedDTO abc)
    {
        int ID = abc.getID();
        double total = abc.getTotal();
        double time = abc.getTime();
        String selectSql = "SELECT ID FROM logged WHERE userID = :userID AND total IS NULL AND time IS NULL ORDER BY ID DESC LIMIT 1";
        Query selectQuery = entityManager.createNativeQuery(selectSql);
        selectQuery.setParameter("userID", ID);
        Integer logId = (Integer) selectQuery.getSingleResult();

        if (logId != null) {
            // Cập nhật total và time cho bản ghi đã tìm thấy
            String updateSql = "UPDATE logged SET total = :total, time = :time WHERE ID = :logId";
            Query updateQuery = entityManager.createNativeQuery(updateSql);
            updateQuery.setParameter("total", total);
            updateQuery.setParameter("time", time);
            updateQuery.setParameter("logId", logId);
            updateQuery.executeUpdate();

            LocalDate currentDate = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String day = currentDate.format(formatter);

            String selectUsedSql = "SELECT total, timeUse FROM used WHERE userID = :userID AND day = :day";
            Query selectUsedQuery = entityManager.createNativeQuery(selectUsedSql);
            selectUsedQuery.setParameter("userID", ID);
            selectUsedQuery.setParameter("day", day);
            List<Object[]> usedResults = selectUsedQuery.getResultList();
            if (!usedResults.isEmpty()) {
                // Nếu bản ghi tồn tại, cộng dồn total và timeUse
                Object[] result = usedResults.get(0);
                Double currentTotal = (Double) result[0];
                Double currentTimeUse = (Double) result[1];
                double newTotal = currentTotal + total;
                double newTimeUse = currentTimeUse + time;

                // Tính speed (giả định speed = total / timeUse)
                double newSpeed = newTimeUse != 0 ? newTotal / newTimeUse : 0;

                // Cập nhật bản ghi trong bảng used
                String updateUsedSql = "UPDATE used SET total = :newTotal, timeUse = :newTimeUse, speed = :newSpeed WHERE userID = :userID AND day = :day";
                Query updateUsedQuery = entityManager.createNativeQuery(updateUsedSql);
                updateUsedQuery.setParameter("newTotal", newTotal);
                updateUsedQuery.setParameter("newTimeUse", newTimeUse);
                updateUsedQuery.setParameter("newSpeed", newSpeed);
                updateUsedQuery.setParameter("userID", ID);
                updateUsedQuery.setParameter("day", day);
                updateUsedQuery.executeUpdate();
            } else {
                // Nếu không có bản ghi, tạo bản ghi mới
                double newSpeed = time != 0 ? total / time : 0; // Tính speed cho bản ghi mới

                String insertUsedSql = "INSERT INTO used (userID, day, timeUse, total, speed) VALUES (:userID, :day, :timeUse, :total, :speed)";
                Query insertUsedQuery = entityManager.createNativeQuery(insertUsedSql);
                insertUsedQuery.setParameter("userID", ID);
                insertUsedQuery.setParameter("day", day);
                insertUsedQuery.setParameter("timeUse", time);
                insertUsedQuery.setParameter("total", total);
                insertUsedQuery.setParameter("speed", newSpeed);
                insertUsedQuery.executeUpdate();
            }
            String sql1 = "UPDATE user SET status = false WHERE userID = " + ID;
            Query qr1 = entityManager.createNativeQuery(sql1);
            qr1.executeUpdate();
            return false;
        } else {
            throw new RuntimeException("No login record found for user ID: " + ID);
        }
    }
}
