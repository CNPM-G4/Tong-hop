package com.example.network.DTO.Response;

public class totalResponseDTO {
    private String day;
    private Double total;

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }
}
