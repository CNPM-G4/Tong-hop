package com.example.network;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
