document.addEventListener("DOMContentLoaded", async function () {
    const pieChart = document.querySelector(".pie-chart");
    const lineChart = document.querySelector(".line-chart");
    const stats = document.querySelectorAll(".stat-box h2");

    // Lấy userID từ localStorage
    const userID = localStorage.getItem("userID");
    console.log("✅ userID từ localStorage:", userID);
    if (!userID) {
        console.error("Không tìm thấy userID trong localStorage!");
        return;
    }

    // Hàm lấy dữ liệu từ API
    async function fetchData() {
        try {
            const response = await fetch(`http://localhost:8092/home?ID=${userID}`);
            if (!response.ok) {
                throw new Error("Không thể lấy dữ liệu từ API");
            }
            return await response.json();
        } catch (error) {
            console.error("Lỗi API:", error);
            return null;
        }
    }

    // Cập nhật biểu đồ
    async function updateCharts() {
        const data = await fetchData();
        if (!data) return;

        // Lấy số liệu từ API
        const dataUsage = data.total || []; // Dữ liệu từ API
        const dayCount = dataUsage.length; // Số ngày có dữ liệu

        // Labels theo số lượng phần tử thực tế
        const labels = Array.from({ length: dayCount }, (_, i) => `Ngày ${i + 1}`);
        const colors = ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF", "#FF9F40", "#8DD776"].slice(0, dayCount);

        if (dayCount === 0) {
            console.warn("API không có dữ liệu total!");
            return;
        }

        // Xóa canvas cũ nếu có
        pieChart.innerHTML = "<canvas id='pieChartCanvas'></canvas>";
        lineChart.innerHTML = "<canvas id='lineChartCanvas'></canvas>";

        // Vẽ Pie Chart
        const pieCtx = document.getElementById("pieChartCanvas").getContext("2d");
        new Chart(pieCtx, {
            type: "pie",
            data: {
                labels: labels,
                datasets: [{
                    data: dataUsage,
                    backgroundColor: colors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: "bottom" }
                }
            }
        });

        // Vẽ Line Chart
        const lineCtx = document.getElementById("lineChartCanvas").getContext("2d");
        new Chart(lineCtx, {
            type: "line",
            data: {
                labels: labels,
                datasets: [{
                    label: "Dữ liệu sử dụng",
                    data: dataUsage,
                    borderColor: "#36A2EB",
                    backgroundColor: "rgba(54, 162, 235, 0.2)",
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: "top" }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    }

    // Cập nhật số liệu thống kê
    async function updateStats() {
        const data = await fetchData();
        if (!data) return;

        const statValues = data.total || []; // Lấy "total" từ API
        stats.forEach((stat, index) => {
            stat.textContent = statValues[index] || 0;
        });
    }

    // Gọi hàm cập nhật dữ liệu
    updateCharts();
    updateStats();
});
document.addEventListener("DOMContentLoaded", async function () {
    const userID = localStorage.getItem("userID");
    if (!userID) {
        console.error("Không tìm thấy userID trong localStorage!");
        return;
    }
    
    async function fetchLoginHistory() {
        try {
            const response = await fetch(`http://localhost:8092/api/history?ID=${userID}`);
            if (!response.ok) throw new Error("Không thể lấy dữ liệu từ API");
            const data = await response.json();
            console.log("📌 API Response:", data);
            return data.date || [];
        } catch (error) {
            console.error("❌ Lỗi API:", error);
            return [];
        }
    }
    
    function processLoginData(rawDates) {
        const loginCounts = Array(7).fill(0);
        const loginDetails = Array.from({ length: 7 }, () => []);
        
        rawDates.forEach(dateStr => {
            const date = new Date(dateStr);
            const dayIndex = (date.getDay() + 6) % 7; // Chuyển đổi sang Thứ 2 -> Chủ Nhật (0-6)
            loginCounts[dayIndex]++;
            loginDetails[dayIndex].push({
                login: date.toLocaleTimeString("vi-VN"),
                logout: "-"
            });
        });
        
        return { loginCounts, loginDetails };
    }
    
    async function updateLoginChart() {
        const rawDates = await fetchLoginHistory();
        const { loginCounts, loginDetails } = processLoginData(rawDates);
        
        const loginData = {
            labels: ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ nhật'],
            datasets: [{
                label: 'Số lần đăng nhập',
                data: loginCounts,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        };
        
        const ctx = document.getElementById('loginChart').getContext('2d');
        const loginChart = new Chart(ctx, {
            type: 'bar',
            data: loginData,
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true } },
                onClick: function (e) {
                    const activePoints = loginChart.getElementsAtEventForMode(e, 'nearest', { intersect: true }, true);
                    if (activePoints.length > 0) {
                        showLoginDetails(activePoints[0].index, loginDetails);
                    }
                }
            }
        });
    }
    
    function showLoginDetails(dayIndex, loginDetails) {
        const detailsDiv = document.getElementById('details');
        const dayLabels = ['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ nhật'];
        const day = dayLabels[dayIndex];
        const details = loginDetails[dayIndex];
        
        let detailsHTML = `<p><strong>${day}:</strong></p>`;
        details.forEach(detail => {
            detailsHTML += `<p>Đăng nhập: ${detail.login} </p>`;
        });
        
        detailsDiv.innerHTML = detailsHTML;
        document.getElementById('chart-container').style.display = 'none';
        document.getElementById('loginDetails').style.display = 'block';
    }
    
    function backToChart() {
        document.getElementById('chart-container').style.display = 'block';
        document.getElementById('loginDetails').style.display = 'none';
    }
    
    updateLoginChart();
});
document.addEventListener("DOMContentLoaded", async function () {
    const userID = localStorage.getItem('userID');
    if (!userID) {
        console.error("Không tìm thấy userID trong localStorage");
        return;
    }

    async function fetchData() {
        try {
            const response = await fetch(`http://localhost:8092/total?ID=${userID}`);
            if (!response.ok) throw new Error("Không thể lấy dữ liệu từ API");
            return await response.json();
        } catch (error) {
            console.error("Lỗi API:", error);
            return null;
        }
    }

    async function updateChart() {
        const data = await fetchData();
        if (!data || !data.total) {
            console.warn("API không có dữ liệu total!");
            return;
        }

        const labels = data.total.map(entry => entry[0]);
        const dataUsage = data.total.map(entry => entry[1]);
        const averageUsage = dataUsage.reduce((a, b) => a + b, 0) / dataUsage.length;
        const barColors = dataUsage.map(usage => usage > averageUsage ? 'red' : 'green');

        const ctx = document.getElementById('data-usage-chart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Dung lượng mạng sử dụng (MB)',
                    data: dataUsage,
                    backgroundColor: barColors,
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: {
                            generateLabels: (chart) => [
                                { text: 'Dung lượng cao (Trên mức trung bình)', fillStyle: 'red' },
                                { text: 'Dung lượng thấp (Dưới mức trung bình)', fillStyle: 'green' }
                            ]
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Dung lượng (MB)'
                        }
                    }
                }
            }
        });
    }

    updateChart();
});

    // Dữ liệu ban đầu cho biểu đồ tốc độ mạng
    let speedData = {
        labels: [],
        datasets: [{
            label: 'Tốc độ mạng (Mbps)',
            data: [],
            fill: false,
            borderColor: 'rgba(75, 192, 192, 1)',
            tension: 0.1
        }]
    };

    const configSpeedChart = {
        type: 'line',
        data: speedData,
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'linear',
                    position: 'bottom'
                },
                y: {
                    beginAtZero: true
                }
            }
        }
    };

    const networkSpeedChart = new Chart(
        document.getElementById('network-speed-chart'),
        configSpeedChart
    );

    // Biến để theo dõi tổng số dung lượng mạng đã sử dụng
    let totalDataUsage = 0;

    // Biến để dừng việc cập nhật tốc độ mạng khi đăng xuất
    let isLoggedIn = true;

    // Hàm để cập nhật tốc độ mạng mỗi 5 giây
    function updateNetworkSpeed() {
        if (!isLoggedIn) return;

        // Random tốc độ mạng giữa 1 và 100 Mbps
        const speed = Math.floor(Math.random() * 100) + 1;
        const currentTime = new Date().getTime();
        const timeInSeconds = Math.floor(currentTime / 1000);

        // Cập nhật ô hiển thị tốc độ mạng
        document.getElementById('network-speed').innerText = `${speed} Mbps`;

        // Cập nhật dữ liệu cho biểu đồ
        speedData.labels.push(timeInSeconds);
        speedData.datasets[0].data.push(speed);
        networkSpeedChart.update();

        // Tính và cập nhật dung lượng mạng đã dùng (1 phút = 3 lần cập nhật tốc độ)
        totalDataUsage += speed * 3;  // Cập nhật tổng dung lượng (dùng 3 lần mỗi phút)
        document.getElementById('data-usage').innerText = `${(totalDataUsage / 1024).toFixed(2)} MB`; // Hiển thị MB
    }

    const speedUpdateInterval = setInterval(updateNetworkSpeed, 1000);

    // Xử lý sự kiện đăng xuất
    document.getElementById('logoutButton').addEventListener('click', async function() {
        // Dừng cập nhật tốc độ mạng khi đăng xuất
        isLoggedIn = false;
        clearInterval(speedUpdateInterval); // Dừng interval

        // Lấy userID từ localStorage
        const userID = localStorage.getItem('userID') || "1";

        // Chuẩn bị dữ liệu gửi đi
        const logoutData = {
            ID: userID,
            total: (totalDataUsage / 1024).toFixed(2), // Chuyển đổi sang MB
            time: ((totalDataUsage / 1024) / 60).toFixed(2) // Giả sử time là tổng MB sử dụng chia cho 60 phút
        };
        console.log("Dữ liệu logout:", logoutData);

        try {
            const response = await fetch("http://localhost:8092/logout", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(logoutData)
            });

            if (!response.ok) {
                throw new Error("Lỗi khi gửi dữ liệu logout!");
            }

            // alert(`Tổng dung lượng mạng đã dùng trong ngày: ${logoutData.total} MB`);
        } catch (error) {
            console.error("Lỗi:", error);
        }
    });
